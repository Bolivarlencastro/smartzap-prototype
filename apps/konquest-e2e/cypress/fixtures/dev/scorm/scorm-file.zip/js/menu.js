//----------- Definição da versão do Scorm utilizada -------------------------
var scorm = pipwerks.SCORM;
scorm.version = "1.2";
scorm.connection.initialize();

//---------- Verifica se conexão com LMS ainda está ativa ----------------
window.onunload = window.onbeforeunload = function()
{
	if(scorm.connection.isActive)
	{	
		pipwerks.UTILS.trace("Finalizando conexão no Unload");
		computeTime();
		scorm.save();
		scorm.quit();
	}
}

if(scorm.connection.isActive){
	//-------------------------------------------------------------------------
	var nomeUsuario = scorm.data.get("cmi.core.student_name");
	var gravarNote = scorm.data.get("cmi.core.lesson_location");
	var licaoGravada = scorm.data.get("cmi.suspend_data");
	var porProgresso = scorm.data.get("cmi.core.score.raw");
	var statusCurso = scorm.data.get("cmi.core.lesson_status");
	var tempoCurso = scorm.data.get("cmi.core.total_time");
	var tempoSessaoAbe = '00:00:00';
	var puxarVar = setTimeout("variaveis()", 1000);
	//------------------------------------------------------------------------
}else{
	var nomeUsuario = 'Anderson Ricarte';
	var gravarNote = 'Campo utilizado para anotações do aluno.'
	var licaoGravada = 5;
	var porProgresso = '0';
	var statusCurso = 'incomplete';
	var tempoCurso = '00:00:00';
	var tempoSessaoAbe = '00:00:00';
}
function variaveis(){
	//-------------------- Recupera tempo percorrido --------------------------
	if(gravarNote=="" || gravarNote == null || gravarNote == undefined){
		gravarNote = 'Campo utilizado para anotações do aluno.';
	}
	scorm.data.set("cmi.core.lesson_location",gravarNote);
	//------------------------------------------------------------------------
	if(licaoGravada=="" || licaoGravada == null || licaoGravada == undefined){
		licaoGravada = 1;
	}else{
		licaoGravada = parseInt(licaoGravada);
		licaoGravada += 1;
	}
	scorm.data.set("cmi.suspend_data",licaoGravada);
	//------------------------------------------------------------------------
	if(porProgresso=="" || porProgresso==null || porProgresso == undefined){
		porProgresso = 0;
	}
	clearTimeout(puxarVar);
	montarTela();
}

var nome = document.querySelector('.nome');
var note = document.querySelector('.note');
var licao = document.querySelector('.licao');
var progresso = document.querySelector('.progresso');
var statusC = document.querySelector('.statusC');
var tempo = document.querySelector('.tempo');
var tempoSessao = document.querySelector('.tempoSessao');

function montarTela(){
	var statusAtul = licaoGravada;
	if(licaoGravada>=5){
		statusAtul = 5;
		//$("#divPDF").css("display", "block");
	}
	$("#s"+statusAtul).addClass("staTualDestaque");
	
	
	nome.innerHTML = "<span>Nome aluno:</span> " + nomeUsuario;
	note.innerHTML = "<span>Anotações:</span> " + gravarNote;
	licao.innerHTML = "<span>Número de acessos:</span> " + licaoGravada;
	progresso.innerHTML = "<span>Porcentagem de progresso:</span> " + porProgresso;
	statusC.innerHTML = "<span>Status do curso:</span> " + statusCurso;
	tempoSessao.innerHTML = "<span>Tempo sessão atual:</span> " + tempoSessaoAbe;
	tempo.innerHTML = "<span>Tempo total de navegação:</span> " + tempoCurso;
	
	
	mudarSta(statusAtul*20);
	/*nome.innerHTML = "<span>cmi.core.student_name:</span> " + nomeUsuario;
	licao.innerHTML = "<span>cmi.suspend_data:</span> " + licaoGravada;
	progresso.innerHTML = "<span>cmi.core.score.raw:</span> " + porProgresso;
	statusC.innerHTML = "<span>cmi.core.lesson_status:</span> " + statusCurso;
	tempo.innerHTML = "<span>cmi.core.total_time:</span> " + tempoCurso;
	tempoSessao.innerHTML = "<span>cmi.core.session_time:</span> " + tempoSessaoAbe;*/
	
}
if(!scorm.connection.isActive){
	montarTela();
}

//----------------Gravar variaveis ----------------------
function mudarSta(numeroRec){
	progresso.innerHTML = "<span>Porcentagem de progresso:</span> " + numeroRec;
	var conIn;
	if(numeroRec == 100){
		conIn = "completed";
	}else{
		conIn = "incomplete";
	}
	statusC.innerHTML = "<span>Status do curso:</span> " + conIn;
	
	if(scorm.connection.isActive){
		scorm.data.set("cmi.core.score.raw",numeroRec);
		scorm.data.set("cmi.core.lesson_status",conIn);
	}
}
function mudaTempo(timeRec){
	tempoSessao.innerHTML = "<span>Tempo sessão atual:</span> " + timeRec;
}

var gravaS;
function gravaSeg(){
	if(scorm.connection.isActive){
		computeTime();
		//mudaTempo();
		scorm.save();
	}
}
gravaS = setInterval("gravaSeg()", 1000);

// ------------------------ Pré-loader ------------------------
(function($){
  $(window).on("load",function(){
	$('#preloader .inner').fadeOut();
    $('#preloader').delay(350).fadeOut('slow');
    $('body').delay(350).css({'overflow': 'visible'});
	$('body').delay(350).css({"overflow-x":"hidden"});
	//var iniCur = setTimeout("iniciarCurso()", 1500);
  });
})(jQuery);
// ---------------------------------------------------------------

   var  element = document.getElementById('conteudo'); 
	function impri(){
		//html2pdf(element);
		var worker = html2pdf().from(element).save('DNA_test_SCORM_PDF.pdf');
	}

/*
nome
licao
progresso
status
tempo
*/













